#include <stdio.h>
#include <string.h>
#include <malloc.h>

///////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct NODE
{
	// ���� ��� �ڷ�
	void* pData;

	// �ڷ� ����
	struct NODE* pPrev;
	struct NODE* pNext;
}NODE;

typedef struct USERDATA
{
	// ��� �Լ� ������
	const char* (*pfGetKey)(void*);

	char szName[64];
	char szPhone[64];
}USERDATA;

NODE*	g_pHead;
NODE*	g_pTail;
int		g_nSize;

///////////////////////////////////////////////////////////////////////////////////////////////////
int InsertAtHead(void* pParam);
int InsertAtTail(void* pParam);
int GetLength();
int InsertAtBefore(NODE* pDstNode, void* pParam);


///////////////////////////////////////////////////////////////////////////////////////////////////
const char* GetKeyFromUserData(USERDATA* pParam)
{
	return pParam->szName;
}


USERDATA* CreateUserData(const char* pszName, const char* pszPhone)
{
	USERDATA* pNew = (USERDATA*)malloc(sizeof(USERDATA));
	memset(pNew, 0, sizeof(USERDATA));
	memcpy(pNew->szName, pszName, sizeof(pNew->szName));
	memcpy(pNew->szPhone, pszPhone, sizeof(pNew->szPhone));

	pNew->pfGetKey = GetKeyFromUserData;

	return pNew;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
void InitList()
{
	g_pHead = (NODE*)malloc(sizeof(NODE));
	g_pTail = (NODE*)malloc(sizeof(NODE));

	g_nSize = 0;
	memset(g_pHead, 0, sizeof(NODE));
	memset(g_pTail, 0, sizeof(NODE));

	g_pHead->pNext = g_pTail;
	g_pTail->pPrev = g_pHead;
}

void ReleaseList()
{
	printf("ReleaseList()\n");

	NODE* pTmp = g_pHead;
	while (pTmp != NULL)
	{
		NODE* pDelete = pTmp;
		pTmp = pTmp->pNext;

		printf("[%p] free\n", pDelete);

		free(pDelete->pData);
		free(pDelete);
	}

	printf("\n");
	g_pHead = NULL;
	g_pTail = NULL;
	g_nSize = 0;
}

void PrintList()
{
	printf("PrintList() : g_nSize [%d], g_pHead [%p], g_pTail [%p]\n", g_nSize, g_pHead, g_pTail);
	NODE* pTmp = g_pHead->pNext;
	while (pTmp != g_pTail)
	{
		USERDATA* pUser = pTmp->pData;
		printf("[0x%p] [%s\t] [0x%p]\n", 
			pTmp->pPrev,
			pUser->pfGetKey(pTmp->pData), 
			pTmp->pNext);
		pTmp = pTmp->pNext;
	}
	printf("\n");
}

NODE* GetAt(int nIdx)
{
	NODE* pTmp = g_pHead->pNext;
	int nCnt = 0;
	while (pTmp != g_pTail)
	{
		if (nIdx == nCnt)
		{
			return pTmp;
		}
		pTmp = pTmp->pNext;
		nCnt++;
	}

	return NULL;
}

int InsertAt(int nIdx, void* pParam)
{
	NODE* pNode = (NODE*)malloc(sizeof(NODE));
	memset(pNode, 0, sizeof(NODE));

	pNode->pData = pParam;

	if (nIdx <= 0)
		InsertAtHead(pParam);
	else if (nIdx >= GetLength())
		InsertAtTail(pParam);
	else
	{
		NODE* pTmp = g_pHead->pNext;
		int nCnt = 0;
		while (pTmp != g_pTail)
		{
			if (nIdx == nCnt)
			{
				InsertAtBefore(pTmp, pParam);
			}
			pTmp = pTmp->pNext;
			nCnt++;
		}
	}
	return 0;
}


int InsertAtHead(void* pParam)
{
	NODE* pNode = (NODE*)malloc(sizeof(NODE));
	memset(pNode, 0, sizeof(NODE));

	// ���� ��� �ڷῡ ���� �ʱ�ȭ
	pNode->pData = pParam;

	// ���� ����Ʈ�� ���� �ʱ�ȭ
	pNode->pNext = g_pHead->pNext;
	pNode->pPrev = g_pHead;

	g_pHead->pNext = pNode;
	pNode->pNext->pPrev = pNode;

	g_nSize++;
	return g_nSize;
}

int InsertAtTail(void* pParam)
{
	InsertAtBefore(g_pTail, pParam);

	return g_nSize;
}

int InsertAtBefore(NODE* pDstNode, void* pParam)
{
	NODE* pNode = (NODE*)malloc(sizeof(NODE));
	memset(pNode, 0, sizeof(NODE));

	pNode->pData = pParam;

	pNode->pNext = pDstNode;
	pNode->pPrev = pDstNode->pPrev;

	pDstNode->pPrev->pNext = pNode;
	pDstNode->pPrev = pNode;

	g_nSize++;
	return g_nSize;
}

NODE* FindNode(const char* pszKey)
{
	NODE* pTmp = g_pHead->pNext;
	// ����ü�� �Լ� �����ͷ� �����Ϸ��� �õ�	
	// USERDATA ����ü
	USERDATA* pUser = pTmp->pData;

	// �Լ� ������
	const char* (*pfGetKey)(void*) = NULL;

	while (pTmp != g_pTail)
	{
		// �Լ������Ϳ� pTmp->pData ����
		pfGetKey = pTmp->pData;

		// ����ü ���� ����
		if (strcmp(pUser->pfGetKey(pTmp->pData), pszKey) == 0)
			return pTmp;

		// �Լ������� 
		if (strcmp(pfGetKey(pTmp->pData), pszKey) == 0)
			return pTmp;

		pTmp = pTmp->pNext;
	}
	return NULL;
}

int DeleteNode(const char* pszKey)
{
	NODE* pNode = FindNode(pszKey);
	//const char* (*pfGetKey)(void*) = NULL;
	//pfGetKey = pNode->pData;

	if (pNode != NULL)
	{
		USERDATA* pUser = pNode->pData;

		pNode->pPrev->pNext = pNode->pNext;
		pNode->pNext->pPrev = pNode->pPrev;

		g_nSize--;
		printf("DeleteNode() \n");
		printf("[0x%p][0x%p\t %s\t][0x%p]\n", pNode->pPrev, pNode, pUser->pfGetKey(pNode->pData), pNode->pNext);
		printf("\n");

		free(pNode->pData);
		free(pNode);
	}
	
	return 0;
}

int GetSize()
{
	return g_nSize;
}

int GetLength()
{
	return GetSize();
}


void main()
{
	InitList();

	USERDATA* pData = NULL;
	pData = CreateUserData("ttt", "010-1111-1111");
	InsertAtTail(pData);
	
	pData = CreateUserData("yy", "010-2222-2222");
	InsertAtTail(pData);

	pData = CreateUserData("etwer", "010-3333-3333");
	InsertAtTail(pData);

	PrintList();

	DeleteNode("etwer");

	ReleaseList();
	return;
}
